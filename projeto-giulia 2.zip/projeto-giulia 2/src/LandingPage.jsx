import { useState, useEffect, useRef } from "react";

const C = {
  navy:"#253C7C",navyD:"#1A2B5E",navyDD:"#111D40",
  blue:"#85ACDC",blueL:"#C2D8EE",blueXL:"#EDF4FB",
  yellow:"#F9C035",yellowD:"#D9A010",yellowL:"#FEF3D0",
  white:"#FFFFFF",cream:"#F8FAFF",
  dark:"#1A2B5E",mid:"#4A6090",muted:"#7A9AC0",border:"#D6E5F4",
};

const HOTMART = "https://pay.hotmart.com/A105968656T?bid=1779578011038";

const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&family=Nunito:wght@400;600;700;800;900&display=swap');
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Nunito',sans-serif;background:${C.cream};color:${C.dark};-webkit-font-smoothing:antialiased}
    html{scroll-behavior:smooth}
    .btn{display:block;width:100%;padding:18px 24px;border-radius:50px;border:none;cursor:pointer;font-family:'Nunito',sans-serif;font-size:16px;font-weight:900;letter-spacing:.5px;text-decoration:none;text-align:center;transition:transform .15s,box-shadow .15s,background .15s;line-height:1.3}
    .btn:hover{transform:translateY(-2px)}
    .btn-yellow{background:${C.yellow};color:${C.navy};box-shadow:0 8px 24px rgba(249,192,53,.45)}
    .btn-yellow:hover{background:${C.yellowD};box-shadow:0 12px 32px rgba(249,192,53,.6)}
    .btn-navy{background:${C.navy};color:#fff;box-shadow:0 8px 24px rgba(37,60,124,.3)}
    .btn-navy:hover{background:${C.navyD}}
    .card{background:#fff;border-radius:20px;padding:22px 20px;box-shadow:0 2px 20px rgba(37,60,124,.08)}
    .sec-label{font-size:11px;font-weight:800;letter-spacing:2.5px;text-transform:uppercase;color:${C.blue};margin-bottom:10px;text-align:center}
    .sec-label-y{color:${C.yellow}}
    .sec-h{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;line-height:1.2;color:${C.dark};margin-bottom:12px;text-align:center}
    .sec-h em{color:${C.navy};font-style:italic}
    .sec-sub{font-size:15px;color:${C.mid};line-height:1.75;text-align:center;max-width:440px;margin:0 auto}
    .check-row{display:flex;gap:10px;align-items:flex-start;font-size:14px;color:${C.mid};margin-bottom:10px;line-height:1.55}
    .ci{width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;flex-shrink:0;margin-top:1px}
    .ci-navy{background:${C.navy};color:#fff}
    .ci-yellow{background:${C.yellow};color:${C.navy}}
    .ci-x{background:#E0E8F4;color:${C.muted}}
    @keyframes float{0%,100%{transform:translateY(0) rotate(-2deg)}50%{transform:translateY(-9px) rotate(-2deg)}}
    @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.03)}}
    @keyframes fadeUp{from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:translateY(0)}}
    .pulse-btn{animation:pulse 2.5s ease-in-out infinite}
  `}</style>
);

function useCountdown(mins=18){
  const[t,setT]=useState(mins*60);
  useEffect(()=>{const i=setInterval(()=>setT(p=>p>0?p-1:0),1000);return()=>clearInterval(i)},[]);
  return{m:String(Math.floor(t/60)).padStart(2,'0'),s:String(t%60).padStart(2,'0')};
}

function useVisible(threshold=0.12){
  const ref=useRef();
  const[vis,setVis]=useState(false);
  useEffect(()=>{
    const obs=new IntersectionObserver(([e])=>{if(e.isIntersecting)setVis(true)},{threshold});
    if(ref.current)obs.observe(ref.current);
    return()=>obs.disconnect();
  },[]);
  return[ref,vis];
}

/* ── PRICE BLOCK ──────────────────────────────────────────── */
function PriceBlock({dark=false}){
  const txt=dark?"rgba(255,255,255,.35)":"rgba(0,0,0,.35)";
  const txtB=dark?"#fff":C.dark;
  const bg=dark?"rgba(249,192,53,.1)":C.yellowL;
  const bdr=dark?"rgba(249,192,53,.25)":`${C.yellow}55`;
  return(
    <div style={{background:bg,borderRadius:16,padding:"18px 16px",border:`1px solid ${bdr}`,textAlign:"center"}}>
      <div style={{fontSize:12,color:txt,textDecoration:"line-through",marginBottom:2}}>De R$ 97,00</div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10,marginBottom:2}}>
        <span style={{fontFamily:"'Playfair Display',serif",fontSize:46,fontWeight:700,color:dark?"#fff":C.navy,lineHeight:1}}>
          <span style={{fontSize:16,fontWeight:400,color:dark?"rgba(255,255,255,.5)":C.muted}}>R$</span>
          {" "}67<span style={{fontSize:16,fontWeight:400,color:dark?"rgba(255,255,255,.5)":C.muted}}>,00</span>
        </span>
        <span style={{background:C.navy,color:"#fff",fontSize:11,fontWeight:900,padding:"4px 12px",borderRadius:50}}>65% OFF</span>
      </div>
      <div style={{fontSize:12,color:dark?"rgba(255,255,255,.4)":C.mid,marginBottom:4}}>no PIX</div>
      <div style={{height:1,background:dark?"rgba(255,255,255,.1)":C.border,margin:"10px 0"}}/>
      <div style={{fontSize:13,color:dark?"rgba(255,255,255,.5)":C.mid}}>
        ou <strong style={{color:dark?"rgba(255,255,255,.75)":C.navy}}>9x de R$ 8,80</strong> no cartão
      </div>
    </div>
  );
}

/* ── LOGO ─────────────────────────────────────────────────── */
function Logo({light=false}){
  return(
    <img src="/logo.png" alt="Giulia Brandes Nutricionista"
      style={{height:42,objectFit:"contain",filter:light?"brightness(0) invert(1)":"none"}}/>
  );
}

/* ── URGENCY BAR ──────────────────────────────────────────── */
function UrgencyBar(){
  const{m,s}=useCountdown(18);
  return(
    <div style={{background:C.yellow,color:C.navy,textAlign:"center",padding:"10px 16px",position:"sticky",top:0,zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",gap:10,flexWrap:"wrap"}}>
      <span style={{fontSize:12,fontWeight:800}}>🔥 OFERTA POR TEMPO LIMITADO</span>
      <div style={{display:"inline-flex",alignItems:"center",gap:6,background:"rgba(37,60,124,.12)",borderRadius:8,padding:"2px 12px"}}>
        <span style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:C.navy}}>{m}:{s}</span>
      </div>
      <span style={{fontSize:12,fontWeight:800}}>65% DE DESCONTO 🔥</span>
    </div>
  );
}

/* ── EBOOK MOCKUP ─────────────────────────────────────────── */
function EbookMockup(){
  return(
    <div style={{display:"flex",justifyContent:"center",margin:"28px 0 8px"}}>
      <div style={{width:185,height:265,background:`linear-gradient(145deg,${C.navyD},${C.navy})`,borderRadius:"6px 14px 14px 6px",padding:"22px 18px 20px 24px",display:"flex",flexDirection:"column",justifyContent:"flex-end",position:"relative",boxShadow:`-6px 10px 40px rgba(26,43,94,.5),3px 3px 0 rgba(0,0,0,.15)`,animation:"float 4s ease-in-out infinite"}}>
        <div style={{position:"absolute",left:0,top:0,bottom:0,width:10,background:"rgba(0,0,0,.2)",borderRadius:"6px 0 0 6px"}}/>
        <div style={{position:"absolute",top:0,left:10,right:0,height:4,background:C.yellow,borderRadius:"0 14px 0 0"}}/>
        <div style={{position:"absolute",top:16,right:14,width:56,height:56,border:`2px solid rgba(249,192,53,.25)`,borderRadius:"50%"}}/>
        <div style={{position:"absolute",top:24,right:22,width:40,height:40,border:`1px solid rgba(249,192,53,.15)`,borderRadius:"50%"}}/>
        <div style={{fontSize:9,letterSpacing:2,textTransform:"uppercase",color:"rgba(255,255,255,.45)",marginBottom:6}}>Guia Completo</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:21,fontWeight:700,color:"#fff",lineHeight:1.18,marginBottom:12}}>Introdução<br/>Alimentar</div>
        <div style={{fontSize:9,color:"rgba(255,255,255,.45)",borderTop:"1px solid rgba(255,255,255,.15)",paddingTop:9}}>Nutri Giulia Brandes · CRN-10/14441</div>
      </div>
    </div>
  );
}

/* ── 1. HERO ──────────────────────────────────────────────── */
function HeroSection(){
  return(
    <div style={{background:`linear-gradient(160deg,${C.blueXL} 0%,${C.cream} 60%,#fff 100%)`,padding:"36px 24px 48px",borderBottom:`4px solid ${C.yellow}`}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div style={{display:"inline-block",background:C.yellowL,color:C.navy,fontSize:11,fontWeight:800,letterSpacing:2,textTransform:"uppercase",padding:"5px 16px",borderRadius:50,marginBottom:14,border:`1px solid ${C.yellow}`}}>
          📥 E-book · Download Imediato
        </div>
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:32,fontWeight:700,lineHeight:1.18,color:C.dark,marginBottom:12}}>
          Ensine seu bebê a comer com{" "}
          <em style={{color:C.navy,fontStyle:"italic"}}>segurança, tranquilidade</em>{" "}
          e sem frustrações
        </h1>
        <p style={{fontSize:15,color:C.mid,lineHeight:1.75,marginBottom:24}}>
          O guia mais completo de introdução alimentar — do primeiro dia aos 2 anos. Com tabelas, checklists e orientações práticas baseadas em evidências.
        </p>
        <EbookMockup/>
        <div style={{margin:"24px 0 20px"}}><PriceBlock/></div>
        <a href={HOTMART} className="btn btn-yellow pulse-btn">EU QUERO APROVEITAR O DESCONTO →</a>
        <div style={{display:"flex",justifyContent:"center",gap:16,marginTop:12,flexWrap:"wrap"}}>
          {["🔒 Pagamento seguro","📥 Acesso imediato","↩ 7 dias de garantia"].map(t=>(
            <span key={t} style={{fontSize:12,color:C.muted}}>{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── 2. PROOF BAR ─────────────────────────────────────────── */
function ProofBar(){
  const items=[["37+","páginas"],["16","tópicos"],["100%","evidências"],["7 dias","garantia"]];
  return(
    <div style={{background:C.navy,padding:"18px 24px"}}>
      <div style={{maxWidth:480,margin:"0 auto",display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
        {items.map(([n,l])=>(
          <div key={n} style={{textAlign:"center"}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:C.yellow,lineHeight:1}}>{n}</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,.5)",marginTop:3,lineHeight:1.3}}>{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── 3. O QUE VOCÊ VAI APRENDER ──────────────────────────── */
function WhatYouLearn(){
  const[ref,vis]=useVisible();
  const items=[
    "Como montar o pratinho de forma correta e nutritiva",
    "Quantas refeições oferecer por cada fase da vida do bebê",
    "Cortes seguros para evitar engasgos — com explicações claras",
    "Quando e como introduzir cada alimento com segurança",
    "Diferença entre reflexo GAG e engasgo real (e o que fazer)",
    "Quais utensílios escolher: cadeirão, prato, copo e talher",
    "Como lidar quando o bebê não quer comer",
    "Temperos permitidos, gorduras e como higienizar os alimentos",
    "Sinais de alergia alimentar e quando buscar ajuda médica",
  ];
  return(
    <div style={{background:C.white,padding:"56px 24px"}} ref={ref}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">O QUE VOCÊ VAI APRENDER</div>
        <h2 className="sec-h">Tudo que você precisa saber <em>em um único guia</em></h2>
        <p className="sec-sub" style={{marginBottom:28}}>Um material completo e prático — para consultar sempre que tiver dúvida, mesmo com o bebê no colo.</p>
        <div style={{display:"flex",flexDirection:"column",gap:0}}>
          {items.map((t,i)=>(
            <div key={i} className="check-row" style={{opacity:vis?1:0,transform:vis?"translateY(0)":"translateY(14px)",transition:`opacity .35s ${i*.05}s ease,transform .35s ${i*.05}s ease`,padding:"10px 0",borderBottom:i<items.length-1?`1px solid ${C.border}`:"none"}}>
              <div className="ci ci-yellow">✓</div>
              <span style={{color:C.dark,fontSize:14}}>{t}</span>
            </div>
          ))}
        </div>
        <div style={{marginTop:28}}>
          <a href={HOTMART} className="btn btn-navy">QUERO ESSE GUIA AGORA →</a>
        </div>
      </div>
    </div>
  );
}

/* ── 4. O QUE ESTÁ INCLUSO (cards detalhados) ────────────── */
function WhatIncluded(){
  const[ref,vis]=useVisible();
  const cards=[
    {n:"01",t:"Guia Completo de Introdução Alimentar",badge:null,items:["Sinais de prontidão e a hora certa de começar","Métodos: Tradicional, BLW e Participativo explicados","Evolução de texturas mês a mês","Tabela completa de alimentos por idade","Alimentos proibidos e por quê","Rotina alimentar por faixa etária","Como montar o pratinho com os grupos alimentares","Sinais de saciedade: como respeitar o bebê","Estratégias para quando o bebê não quer comer"],bonus:"🎁 BÔNUS: Manual de Higienização e Conservação"},
    {n:"02",t:"Manual de Utensílios",badge:"BÔNUS",items:["Cadeiras de refeição: critérios e modelos indicados","Pratinhos: silicone, inox ou bambu — qual escolher","Copos: abertos vs. 360° — prós e contras","Talheres: material, formato e marcas","Babadores: como evitar sujeirada"],bonus:"💡 Com fotos e indicações de onde comprar"},
    {n:"03",t:"Segurança: Engasgo e Alergias",badge:"URGENTE",items:["GAG x Engasgo: diferença explicada com clareza","Passo a passo em caso de engasgo real","Alimentos de risco e como oferecer com segurança","Alergias leves x graves: sinais para observar","Quando ligar para o SAMU (192) ou Bombeiros (193)"],bonus:"🚨 Protocolo completo de primeiros socorros"},
  ];
  const bStyle={BÔNUS:{bg:C.yellowL,c:C.navy},URGENTE:{bg:"#FFE8E8",c:"#C02020"}};
  return(
    <div style={{background:C.blueXL,padding:"56px 24px"}} ref={ref}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">O QUE VOCÊ TERÁ ACESSO</div>
        <h2 className="sec-h">Conteúdo <em>completo e detalhado</em></h2>
        <div style={{display:"flex",flexDirection:"column",gap:18,marginTop:28}}>
          {cards.map((c,i)=>(
            <div key={i} className="card" style={{border:`1px solid ${C.border}`,opacity:vis?1:0,transform:vis?"translateY(0)":"translateY(20px)",transition:`opacity .45s ${i*.1}s ease,transform .45s ${i*.1}s ease`}}>
              <div style={{display:"flex",alignItems:"flex-start",gap:12,marginBottom:14,paddingBottom:14,borderBottom:`1px solid ${C.border}`}}>
                <span style={{fontFamily:"'Playfair Display',serif",fontSize:34,fontWeight:700,color:C.blueL,lineHeight:1,flexShrink:0}}>{c.n}</span>
                <div style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:700,color:C.dark,lineHeight:1.3}}>
                  {c.t}
                  {c.badge&&<span style={{display:"inline-block",background:bStyle[c.badge].bg,color:bStyle[c.badge].c,fontSize:9,fontWeight:900,padding:"2px 8px",borderRadius:50,marginLeft:6,letterSpacing:1,verticalAlign:"middle"}}>{c.badge}</span>}
                </div>
              </div>
              <div style={{marginBottom:14}}>
                {c.items.map((it,j)=>(
                  <div key={j} className="check-row"><div className="ci ci-navy">✓</div><span>{it}</span></div>
                ))}
              </div>
              <div style={{background:C.yellowL,borderRadius:10,padding:"10px 14px",fontSize:13,color:C.navyD,fontWeight:700,border:`1px solid ${C.yellow}44`}}>{c.bonus}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── 5. CTA MEIO ──────────────────────────────────────────── */
function CtaMid(){
  return(
    <div style={{background:C.navy,padding:"40px 24px",textAlign:"center"}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:700,color:"#fff",marginBottom:6}}>Não perca essa oferta, mamãe!</div>
        <div style={{fontSize:14,color:"rgba(255,255,255,.6)",marginBottom:20}}>65% de desconto — por tempo limitado</div>
        <a href={HOTMART} className="btn btn-yellow">EU QUERO APROVEITAR! →</a>
      </div>
    </div>
  );
}

/* ── 6. DEPOIMENTOS ───────────────────────────────────────── */
function Testimonials(){
  const[ref,vis]=useVisible();
  const items=[
    {ini:"AM",name:"Ana Melo",sub:"Mãe da Sofia, 7 meses",txt:"Estava apavorada com o engasgo e esse guia mudou tudo. A diferença entre GAG e engasgo que explica é incrível — nunca vi isso tão bem explicado!"},
    {ini:"CF",name:"Camila Ferreira",sub:"Mãe do Bernardo, 8 meses",txt:"Comprei achando que sabia tudo e aprendi coisas que nunca vi em lugar nenhum. A tabela de alimentos por idade uso todo dia. Material muito completo!"},
    {ini:"RL",name:"Rafaela Lopes",sub:"Mãe do Théo, 9 meses",txt:"Meu filho não queria comer nada. Depois do guia entendi que estava forçando demais. Mudei tudo e em uma semana a diferença foi enorme!"},
    {ini:"PS",name:"Priscila Santos",sub:"Mãe da Laura, 8 meses",txt:"A seção de utensílios me poupou muito dinheiro! Eu estava prestes a comprar tudo errado. Agora sei exatamente o que escolher e por quê."},
  ];
  return(
    <div style={{background:C.navy,padding:"56px 24px"}} ref={ref}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label sec-label-y">O QUE AS MAMÃES DIZEM</div>
        <h2 className="sec-h" style={{color:"#fff"}}>Resultados de quem <em style={{color:C.yellow}}>já colocou em prática</em></h2>
        <div style={{display:"flex",flexDirection:"column",gap:14,marginTop:28}}>
          {items.map((it,i)=>(
            <div key={i} style={{background:"rgba(255,255,255,.07)",border:"1px solid rgba(255,255,255,.12)",borderRadius:18,padding:"20px 18px",opacity:vis?1:0,transform:vis?"translateY(0)":"translateY(16px)",transition:`opacity .4s ${i*.08}s ease,transform .4s ${i*.08}s ease`}}>
              <div style={{color:C.yellow,fontSize:14,letterSpacing:3,marginBottom:10}}>★★★★★</div>
              <p style={{fontSize:14,color:"rgba(255,255,255,.85)",lineHeight:1.72,marginBottom:14,fontStyle:"italic"}}>"{it.txt}"</p>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:34,height:34,borderRadius:"50%",background:C.blue,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:C.navy,flexShrink:0}}>{it.ini}</div>
                <div>
                  <div style={{fontSize:13,fontWeight:700,color:"rgba(255,255,255,.9)"}}>{it.name}</div>
                  <div style={{fontSize:11,color:"rgba(255,255,255,.4)"}}>{it.sub}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── 7. MÉTODOS ───────────────────────────────────────────── */
function Methods(){
  const[ref,vis]=useVisible();
  const items=[
    {e:"🥄",t:"Tradicional",d:"Alimentos amassados no garfo e oferecidos na colher. Nunca liquidificados — o guia explica o porquê e como evoluir a textura.",feat:false},
    {e:"🤝",t:"Participativo",d:"O bebê explora com as mãos E recebe no talher. Proporciona autonomia com segurança — o método mais indicado.",feat:true},
    {e:"👶",t:"BLW",d:"O bebê conduz a refeição com alimentos macios em pedaços. O guia ensina os cortes certos para cada fase de desenvolvimento.",feat:false},
  ];
  return(
    <div style={{background:C.white,padding:"56px 24px"}} ref={ref}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">COMO OFERECER OS ALIMENTOS</div>
        <h2 className="sec-h">Qual método combina <em>com você?</em></h2>
        <p className="sec-sub" style={{marginBottom:28}}>O guia explica os três métodos para você escolher com total segurança.</p>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {items.map((it,i)=>(
            <div key={i} className="card" style={{border:it.feat?`2px solid ${C.yellow}`:`1px solid ${C.border}`,opacity:vis?1:0,transition:`opacity .4s ${i*.1}s ease,transform .4s ${i*.1}s ease`,transform:vis?"translateY(0)":"translateY(16px)"}}>
              {it.feat&&<div style={{fontSize:11,fontWeight:900,letterSpacing:1,color:C.navy,marginBottom:10,padding:"4px 12px",background:C.yellowL,borderRadius:50,display:"inline-block",border:`1px solid ${C.yellow}`}}>⭐ MAIS INDICADO</div>}
              <div style={{display:"flex",alignItems:"flex-start",gap:14}}>
                <span style={{fontSize:30,flexShrink:0}}>{it.e}</span>
                <div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:700,color:C.dark,marginBottom:5}}>{it.t}</div>
                  <div style={{fontSize:13,color:C.mid,lineHeight:1.65}}>{it.d}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── 8. PARA QUEM É ───────────────────────────────────────── */
function ForWhom(){
  return(
    <div style={{background:C.blueXL,padding:"56px 24px"}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">PARA QUEM É?</div>
        <h2 className="sec-h">Este guia <em>é para você</em> se...</h2>
        <div className="card" style={{marginTop:24,marginBottom:14,borderLeft:`4px solid ${C.navy}`,border:`1px solid ${C.border}`}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:700,color:C.navy,marginBottom:14,paddingBottom:12,borderBottom:`1px solid ${C.border}`}}>✅ É para você</div>
          {["Está prestes a iniciar a IA e quer começar com segurança","Tem medo de engasgo e quer entender o que é normal e o que é emergência","Quer uma referência prática para consultar sempre, sem pesquisar no Google","Quer montar refeições nutritivas sem complicar a vida","Pai, mãe, avó ou cuidador que quer estar preparado","Já iniciou a IA e tem dúvidas sobre as próximas etapas"].map((t,i)=>(
            <div key={i} className="check-row"><div className="ci ci-navy">✓</div><span>{t}</span></div>
          ))}
        </div>
        <div className="card" style={{borderLeft:`4px solid ${C.border}`,border:`1px solid ${C.border}`}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:700,color:C.muted,marginBottom:14,paddingBottom:12,borderBottom:`1px solid ${C.border}`}}>✗ Não é para você</div>
          {["Busca plano alimentar personalizado e individualizado","Quer substituir o acompanhamento com nutricionista ou pediatra","Seu bebê já tem mais de 2 anos e a IA está completa","Quer somente receitas culinárias detalhadas"].map((t,i)=>(
            <div key={i} className="check-row"><div className="ci ci-x">✗</div><span style={{color:C.muted}}>{t}</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── 9. GARANTIA ──────────────────────────────────────────── */
function Guarantee(){
  return(
    <div style={{background:C.yellowL,padding:"48px 24px",borderTop:`3px solid ${C.yellow}`,borderBottom:`3px solid ${C.yellow}`}}>
      <div style={{maxWidth:480,margin:"0 auto",display:"flex",gap:24,alignItems:"center",flexWrap:"wrap",justifyContent:"center"}}>
        <div style={{width:104,height:104,background:"#fff",border:`3px solid ${C.yellow}`,borderRadius:"50%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flexShrink:0,boxShadow:`0 8px 24px rgba(249,192,53,.3)`,textAlign:"center"}}>
          <span style={{fontFamily:"'Playfair Display',serif",fontSize:36,fontWeight:700,color:C.navy,lineHeight:1}}>7</span>
          <span style={{fontSize:9,fontWeight:800,letterSpacing:1,textTransform:"uppercase",color:C.mid,lineHeight:1.3}}>dias de<br/>garantia</span>
        </div>
        <div style={{flex:1,minWidth:200}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:700,color:C.navy,marginBottom:8}}>Garantia incondicional de 7 dias</div>
          <div style={{fontSize:14,color:C.mid,lineHeight:1.75}}>Se por qualquer motivo você não ficar satisfeita, é só pedir o reembolso dentro de 7 dias corridos após a compra. A Hotmart processa o estorno automaticamente — sem questionamentos e sem burocracia.</div>
        </div>
      </div>
    </div>
  );
}

/* ── 10. FAQ ──────────────────────────────────────────────── */
function Faq(){
  const[open,setOpen]=useState(null);
  const faqs=[
    ["Qual a forma de pagamento?","Você pode pagar por PIX (R$ 67,00) ou cartão de crédito em até 9x de R$ 8,80."],
    ["Como tenho acesso ao guia?","O acesso é imediato. Após a confirmação do pagamento pela Hotmart, você recebe o link de download no e-mail cadastrado. O PDF abre em qualquer dispositivo — celular, tablet ou computador."],
    ["O guia substitui consulta com nutricionista?","Não. O guia oferece orientações gerais baseadas nas recomendações atuais, mas não substitui o acompanhamento individualizado com nutricionista e pediatra do seu bebê."],
    ["Para qual idade é indicado?","O guia cobre do início da introdução alimentar (6 meses) até os 2 anos. Ideal para quem está se preparando para começar ou para quem já iniciou e tem dúvidas sobre as próximas etapas."],
    ["Posso usar mesmo que meu bebê já tenha começado?","Sim! O guia aborda todas as fases — evolução de texturas, novos alimentos, aumento de refeições e muito mais. Tem conteúdo relevante para cada etapa."],
    ["Tenho garantia?","Sim! 7 dias de garantia incondicional pela Hotmart. Se não ficar satisfeita por qualquer motivo, solicite o reembolso diretamente na plataforma — sem perguntas."],
  ];
  return(
    <div style={{background:C.white,padding:"56px 24px"}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">TIRE SUAS DÚVIDAS</div>
        <h2 className="sec-h" style={{marginBottom:28}}>Perguntas <em>frequentes</em></h2>
        {faqs.map(([q,a],i)=>(
          <div key={i} style={{borderBottom:`1px solid ${C.border}`}}>
            <button onClick={()=>setOpen(open===i?null:i)} style={{width:"100%",background:"none",border:"none",cursor:"pointer",textAlign:"left",padding:"16px 0",display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,fontFamily:"'Nunito',sans-serif",fontSize:14,fontWeight:700,color:open===i?C.navy:C.dark}}>
              <span>{q}</span>
              <div style={{width:26,height:26,borderRadius:"50%",background:open===i?C.navy:C.blueXL,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,color:open===i?"#fff":C.navy,flexShrink:0,transition:"all .2s",transform:open===i?"rotate(180deg)":"none"}}>▾</div>
            </button>
            <div style={{maxHeight:open===i?400:0,overflow:"hidden",transition:"max-height .3s ease",fontSize:14,color:C.mid,lineHeight:1.75,paddingBottom:open===i?16:0}}>{a}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── 11. SOBRE A GIULIA (com foto) ───────────────────────── */
function About(){
  return(
    <div style={{background:C.blueXL,padding:"56px 24px"}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label">CONHEÇA A NUTRI</div>
        <h2 className="sec-h">Criado por quem <em>entende de verdade</em></h2>

        {/* Foto da Giulia */}
        <div style={{display:"flex",justifyContent:"center",margin:"24px 0"}}>
          <div style={{position:"relative",width:160,height:160}}>
            <img
              src="/giulia.jpg"
              alt="Nutri Giulia Brandes"
              style={{width:160,height:160,borderRadius:"50%",objectFit:"cover",objectPosition:"top",border:`4px solid ${C.yellow}`,boxShadow:`0 8px 32px rgba(37,60,124,.25)`}}
              onError={e=>{
                e.target.style.display="none";
                e.target.nextSibling.style.display="flex";
              }}
            />
            {/* Fallback se não tiver foto */}
            <div style={{width:160,height:160,borderRadius:"50%",background:`linear-gradient(145deg,${C.blue},${C.navy})`,display:"none",alignItems:"center",justifyContent:"center",fontSize:56,border:`4px solid ${C.yellow}`,boxShadow:`0 8px 32px rgba(37,60,124,.25)`}}>👩‍⚕️</div>
            {/* Badge CRN */}
            <div style={{position:"absolute",bottom:4,right:-4,background:C.yellow,color:C.navy,fontSize:9,fontWeight:900,padding:"3px 8px",borderRadius:50,letterSpacing:.5,boxShadow:"0 2px 8px rgba(0,0,0,.15)"}}>CRN-10/14441</div>
          </div>
        </div>

        {/* Logo abaixo da foto */}
        <div style={{display:"flex",justifyContent:"center",marginBottom:20}}>
          <Logo/>
        </div>

        <p style={{fontSize:15,color:C.mid,lineHeight:1.82,marginBottom:14,textAlign:"center"}}>
          A <strong style={{color:C.navy}}>Nutri Giulia Brandes</strong> é nutricionista especializada em alimentação infantil com registro CRN-10/14441. Ela acredita que a introdução alimentar não precisa ser um bicho de sete cabeças — desde que você tenha as informações certas.
        </p>
        <p style={{fontSize:15,color:C.mid,lineHeight:1.82,textAlign:"center"}}>
          Este guia reúne o mesmo conteúdo que ela compartilha em consultas individuais, agora acessível para todas as famílias em um material prático e fácil de consultar a qualquer momento.
        </p>

        <div style={{marginTop:28}}>
          <a href={HOTMART} className="btn btn-yellow">QUERO O GUIA DE INTRODUÇÃO ALIMENTAR! →</a>
        </div>
      </div>
    </div>
  );
}

/* ── 12. CTA FINAL ────────────────────────────────────────── */
function FinalCta(){
  const{m,s}=useCountdown(18);
  return(
    <div id="comprar" style={{background:`linear-gradient(145deg,${C.navyD},${C.navyDD})`,padding:"64px 24px"}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div className="sec-label sec-label-y">ACESSO IMEDIATO</div>
        <h2 className="sec-h" style={{color:"#fff"}}>Comece ainda hoje com <em style={{color:C.yellow}}>65% de desconto</em></h2>
        <p style={{fontSize:14,color:"rgba(255,255,255,.6)",lineHeight:1.75,textAlign:"center",marginBottom:28}}>O guia mais completo de introdução alimentar — tudo que você precisa para começar com segurança e confiança.</p>

        <div style={{background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.12)",borderRadius:22,padding:"28px 22px"}}>

          {/* Countdown */}
          <div style={{textAlign:"center",marginBottom:22,padding:"12px",background:"rgba(249,192,53,.1)",borderRadius:14,border:"1px solid rgba(249,192,53,.25)"}}>
            <div style={{fontSize:11,color:"rgba(255,255,255,.45)",marginBottom:4,letterSpacing:1}}>⏱ OFERTA EXPIRA EM</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:36,fontWeight:700,color:C.yellow}}>{m}:{s}</div>
          </div>

          {/* Incluso */}
          <div style={{marginBottom:22,paddingBottom:20,borderBottom:"1px solid rgba(255,255,255,.1)"}}>
            {["Guia Completo de Introdução Alimentar (37 págs.)","Manual de Utensílios com fotos e indicações","Protocolo de Engasgo e Segurança Alimentar","Bônus: Higienização e Conservação dos Alimentos","Acesso vitalício + todas as atualizações futuras"].map((t,i)=>(
              <div key={i} style={{display:"flex",gap:10,alignItems:"center",marginBottom:10,fontSize:13,color:"rgba(255,255,255,.82)"}}>
                <div style={{width:20,height:20,borderRadius:"50%",background:C.yellow,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:900,flexShrink:0,color:C.navy}}>✓</div>
                {t}
              </div>
            ))}
          </div>

          {/* Price */}
          <div style={{marginBottom:22}}><PriceBlock dark/></div>

          <a href={HOTMART} className="btn btn-yellow" style={{fontSize:15,marginBottom:12}}>
            EU QUERO APROVEITAR E COMPRAR AGORA →
          </a>
          <div style={{display:"flex",justifyContent:"center",gap:12,flexWrap:"wrap"}}>
            {["🔒 Hotmart","📥 Imediato","↩ 7 dias de garantia"].map(t=>(
              <span key={t} style={{fontSize:11,color:"rgba(255,255,255,.3)"}}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── FOOTER ───────────────────────────────────────────────── */
function Footer(){
  return(
    <div style={{background:C.navyDD,padding:"32px 24px",textAlign:"center",borderTop:`4px solid ${C.yellow}`}}>
      <div style={{maxWidth:480,margin:"0 auto"}}>
        <div style={{display:"flex",justifyContent:"center",marginBottom:14}}><Logo light/></div>
        <div style={{fontSize:12,color:"rgba(255,255,255,.22)",lineHeight:1.9}}>
          CRN-10/14441 · Nutricionista Giulia Brandes<br/>
          Este material tem caráter educativo e não substitui acompanhamento nutricional ou médico individualizado.<br/>
          Plataforma de venda: Hotmart · Pagamento 100% seguro<br/>
          © {new Date().getFullYear()} Nutri Giulia Brandes · Todos os direitos reservados
        </div>
      </div>
    </div>
  );
}

/* ── STICKY BOTTOM ────────────────────────────────────────── */
function StickyBottom(){
  const[show,setShow]=useState(false);
  useEffect(()=>{
    const h=()=>setShow(window.scrollY>500);
    window.addEventListener("scroll",h);
    return()=>window.removeEventListener("scroll",h);
  },[]);
  if(!show)return null;
  return(
    <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:200,background:"rgba(255,255,255,.97)",backdropFilter:"blur(10px)",borderTop:`2px solid ${C.yellow}`,padding:"11px 20px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 -4px 24px rgba(37,60,124,.15)"}}>
      <div style={{flex:1}}>
        <div style={{fontSize:11,color:C.muted}}>No PIX</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:700,color:C.navy}}>R$ 67,00</div>
        <div style={{fontSize:11,color:C.muted}}>ou 9x R$ 8,80</div>
      </div>
      <a href={HOTMART} className="btn btn-yellow" style={{flex:"0 0 auto",padding:"13px 22px",fontSize:13,width:"auto"}}>COMPRAR →</a>
    </div>
  );
}

/* ── APP ──────────────────────────────────────────────────── */
export default function App(){
  return(
    <>
      <GlobalStyle/>
      <UrgencyBar/>
      <HeroSection/>
      <ProofBar/>
      <WhatYouLearn/>
      <WhatIncluded/>
      <CtaMid/>
      <Testimonials/>
      <Methods/>
      <ForWhom/>
      <Guarantee/>
      <Faq/>
      <About/>
      <FinalCta/>
      <Footer/>
      <StickyBottom/>
    </>
  );
}
